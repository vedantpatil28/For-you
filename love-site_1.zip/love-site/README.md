# For Her — a little website

## How to add your photos
1. Open the `photos` folder.
2. Drop in your own pictures, named exactly:
   `photo1.jpg`, `photo2.jpg`, `photo3.jpg`, `photo4.jpg`, `photo5.jpg`, `photo6.jpg`
   (jpg or png both work — if you use png, rename the file extension to match, e.g. `photo1.jpg`)
3. That's it. Any slot without a matching file just shows a soft placeholder, so nothing ever looks broken while you're still adding photos.

Want more or fewer than 6 photos? Open `index.html`, find `photoCount: 6` near the top of the `<script>` section, and change the number. Also update the `photoCaptions` list right below it to match.

## How to edit the words
Everything you'd want to personalize lives in one place: open `index.html` and look for the `CONFIG` object near the bottom (it's clearly marked with a comment). You can change:
- The landing line, hero title/subtitle
- `startDate` — set this to when you got together, and the "days of us" counter updates itself automatically
- The closing message and signature
- The 8 sealed notes — add, remove, or rewrite any of them freely

You don't need to touch anything else in the file.

## How to put it on GitHub Pages (so she can open it from a link)
1. Create a new repository on GitHub.
2. Upload `index.html`, the `README.md`, and the `photos` folder (with your photos inside).
3. In the repo, go to **Settings → Pages**.
4. Under "Build and deployment," set the source to the `main` branch, root folder.
5. Save. GitHub will give you a link like `https://yourusername.github.io/reponame/` within a minute or two — that's the link you send her.

## The heart of the experience
This site now has two things that make it more than just a page to look at:

**Mood system** — the background atmosphere shifts based on what she's reading. Open a tender note and the page softens into blush calm. Open a fire note and it warms into ember tones. Devotion turns deep plum, playful turns gold, cat notes turn warm amber. It settles back to a soft neutral in between, so it always feels responsive, not jarring. Colors live in the `.mood-*` CSS classes near the top of the `<style>` block if you ever want to adjust one.

**Finale unlock** — once she's opened every single sealed note *and* the scratch card, a final message unlocks automatically: a longer, more personal letter from you, with its own warm "forever" glow. This is the payoff for going through the whole thing — edit it in `CONFIG.finaleTitle`, `CONFIG.finaleBody`, and `CONFIG.finaleSignature`. Write this one yourself, in your own words — it's meant to be the most "you" part of the whole site.

There are also small hearts under the days counter that quietly fill in as she opens things — a gentle nudge to keep going, without feeling like a checklist.

## Cat sounds (optional)
The site plays a cute synthesized "meow" chirp by default when you pet the cat mascot or finish scratching the scratch-card note — nothing to set up. If you want a real meow sound instead, drop an mp3 file into the `sounds` folder named exactly:
`meow.mp3`
The site will automatically use it in place of the synthesized sound.

## What's interactive now
- **Cat mascot** (bottom-right corner) — click or tap it to pet it. It bounces, meows, and says something in a speech bubble.
- **Paw prints** — follow your cursor lightly across the page.
- **Scratch-to-reveal card** — drag across it like a real scratch card instead of tapping to open.
- **Sound toggle** (top-right corner) — mutes the meow sounds if needed.

## Notes
- Works on mobile and desktop.
- No external accounts, backend, or database needed — it's a single self-contained page.
- All photos and text stay in your repo; nothing is sent anywhere else.
