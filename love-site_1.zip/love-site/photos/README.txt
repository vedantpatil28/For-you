Drop your photos in here, named exactly:
photo1.jpg
photo2.jpg
photo3.jpg
photo4.jpg
photo5.jpg
photo6.jpg

(You can add more — see the main README.md for how to raise the photo count.)
