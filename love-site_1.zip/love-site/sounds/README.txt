Optional: drop a real meow sound in here named exactly:
meow.mp3

If this file isn't here, the site automatically plays a
cute synthesized "meow" chirp instead — nothing breaks either way.
